import { countries } from "./services/countries.service.js";
import { createCardsList } from "./services/dom.service.js";

createCardsList(countries);
